import random
arqs=['tai20_5.txt',
        'tai20_10.txt',
         "tai20_10.txt",
    "tai20_20.txt",
    "tai50_5.txt",
    "tai50_10.txt",
    "tai50_20.txt",
    "tai100_5.txt",
    "tai100_10.txt",
    "tai100_20.txt",
    "tai200_10.txt"]
#arq = open("tai20_10.txt", 'r')

for file in arqs:
    arq = open(file, 'r')
    
    data = []
    controle = []
    previos = ""



    for line in arq.readlines():

        if line[0] == " " and line[2] != " ":
            data.append(line)
        if "number of jobs, number of machines, initial seed, upper bound and lower bound :" in previos and len(controle) == 0:
            controle.append(line)
        previos = line
    controle = controle[0].split(' ')
    count = 0

    for value in controle:
        if value.isnumeric():
            count += 1
            if count == 2:
                separador = int(value)
                break

    blocos = []
    contentBloco = ""
    i = 0

    for line in data:
        if i == separador:
            blocos.append(contentBloco)
            i = 0
            contentBloco = ""
            break
        contentBloco += line
        i += 1

    for bloco in blocos:
        print(bloco)
    arq.close()



def criarPopulacaoInicial(instance,tam):
    nElem= len(instance[0])
    return[random.sample(range (1,nElem+1) for _ in range (tam))]


for instancia in listaInstancias:
    listaInstancias = lerInstancias(arqs)
    tamanhoPop = 4
    tempoMaximo = 1 #definimos o tamanho



      
    populacao = criarPopulacaoInicial(instancia, tamanhoPop)
    print(populacao)
    break
