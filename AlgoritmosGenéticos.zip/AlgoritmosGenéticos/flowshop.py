import random
import time
import sys
import json
#def makespan(instancia, solucao)
#copiar função fornecida
def makespan (instancia, solucao):
    nM = len(instancia)
    tempo = [0] * nM
    tarefa = [0] * len(solucao)
    for t in solucao:
        if tarefa[t-1] == 1:
            return "SOLUÇÃO INVÁLIDA: tarefa repetida!"
        else:
            tarefa[t-1] = 1
        for m in range (nM):
            if tempo[m] < tempo[m-1] and m!=0:
                tempo[m] = tempo[m-1] 
            tempo[m] += instancia[m][t-1] 
    return tempo[nM-1]

#Exemplo de uso
instancia = [[54, 83, 15],
             [79, 3, 11],
             [16, 89, 49],
             [66, 58, 31],
             [58, 56, 20]]
solucao1 = [1,2,3]
solucao2 = [2,1,3]
solucao3 = [3,1,2]
solucao4 = [3,1,3]
print (makespan(instancia,solucao1))
print (makespan(instancia,solucao2))
print (makespan(instancia,solucao3))
print (makespan(instancia,solucao4))

def lerInstancias(listaArquivos):
    lerInstancia = []
    for file in listaArquivos:
        firstlerInstance=[]

#ler a primeira instância de cada um dos dez arquivos, armazenar em uma lista e retornar essa lista

arqs=['tai20_5.txt',
        'tai20_10.txt',
         "tai20_10.txt",
    "tai20_20.txt",
    "tai50_5.txt",
    "tai50_10.txt",
    "tai50_20.txt",
    "tai100_5.txt",
    "tai100_10.txt",
    "tai100_20.txt",
    "tai200_10.txt"]
#arq = open("tai20_10.txt", 'r')

for file in arqs:
    arq = open(file, 'r')
    
    data = []
    controle = []
    previos = ""

    for line in arq.readlines():

        if line[0] == " " and line[2] != " ":
            data.append(line)
        if "number of jobs, number of machines, initial seed, upper bound and lower bound :" in previos and len(controle) == 0:
            controle.append(line)
        previos = line
    controle = controle[0].split(' ')
    count = 0

    for value in controle:
        if value.isnumeric():
            count += 1
            if count == 2:
                separador = int(value)
                break

    blocos = []
    contentBloco = ""
    i = 0

    for line in data:
        if i == separador:
            blocos.append(contentBloco)
            i = 0
            contentBloco = ""
            break
        contentBloco += line
        i += 1

    for bloco in blocos:
        print(bloco)
    arq.close()
    break #retira depois

#criar uma lista de soluções aleatórias (podem definir outro critério se desejarem) com o tamanho repassado

listaInstancias = lerInstancias(arqs)
# for instance in listaInstancias:
#     print(instance)
#     tamanhoPop = 4
#     tempoMaximo = 1 #definimos o tamanho

def pop(min,max):
    return(random.randint(min,max)for _ in range(pop))
for instancia in listaInstancias:
    tamanhoPop = 4
    tempoMaximo = 1 #definimos o tamanho

    

def criarPopulacaoInicial(instance,tam):
    nElem= len(instancia[4])
    return[random.sample(range (min,max) for _ in range (tamanhoPop))]
    #return(pop(0,9) for i in range(instance))


#def avaliarPop(populacao):


    pass
#usar a função makespan para avalaiar a aptidão de cada elemento da população

def retornaMelhorSolucao(populacao, aptidaoPop):
    pass
#retorna a melhor solucao dentre a populacao atual

def selecionarPop(populacao, aptidaoPop):
    pass
#função deve retornar quais elementos serão recombinados e com quem (pode fazer uso da aptidao ou não para o critério de seleção)

def recombinacao(populacaoSelecionada):
    pass
#função deve usar o operador de recombinacao (definido pelo grupo_ para gerar novas soluções filhas

def mutacao(novasSolucoes):
    pass
#função deve usar o operador de mutacao (definido pelo grupo) para modificar as soluções filhas (não precisa ser todas)

def selecionarNovaGeracao(populacaoAtual, novasSolucoes):
    pass
#função deve criar uma nova população com as soluções novas (eliminando as antigas ou usando outro critério de seleção desejado)

def salvarRelatorio(relatorio):
    pass
#computar o lower bound, upper bound, valores médios e desvios (tanto para aptidão quanto para o tempo de execução) para cada instância
#salvar em formato de tabela (pode ser um CSV) em um arquivo






# relatorio = [dict() for instancia in range(listaInstancias)]
# for instancia in range (listaInstancias):
   

    #Para cada instância executar todo o algoritmo 10 vezes
    # melhoresSolucoes = relatorio[instancia]


    for it in range (10):
        melhorSolucao = {'solucao':[], 'aptidao':sys.maxint, 'tempoFinal':0}
        tempoInicial = time.time()
        
        populacao = criarPopulacaoInicial(instance)
        print(pop)
        break
        

    
        while true:
            if tempoMaximo <= time.time() - tempoInicial:
                break
            if criterioParada2 == true:
                break
            aptidaoPop = avaliarPop(populacao)
            melhorSolucaoAtual = retornaMelhorSolucao(populacao, aptidaoPop)
            if melhorSolucao['aptidao'] > melhorSolucaoAtual['aptidao']:
                melhorSolucao = melhorSolucaoAtual
            populacaoSelecionada = selecionarPop(populacao, aptidaoPop)
            novasSolucoes = recombinacao(populacaoSelecionada)
            novasSolucoes = mutacao(novasSolucoes)
            populacao = selecionarNovaGeracao(populacao, novasSolucoes)
        melhorSolucao['tempoFinal'] = time.time() - tempoInicial
        print(melhorSolucao)
        melhoresSolucoes = melhoresSolucoes | melhorSolucao
    relatorio[instancia] = melhoresSolucoes
# salvarRelatorio(relatorio)