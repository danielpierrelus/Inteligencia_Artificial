
arquivo = open('tai20_5.txt', 'r')
for linha in arquivo:
    print(linha)
arquivo.close()


# arq= open('tai20_5.txt','r')
# i = 0
# for linha in arq:
#     linha = linha.rstrip()
#     if [linha[2] in linha :
#         i = i + 1
#         print(linha)

# arq.close()

#manipulador= open ('tai20_5.txt')
#print(manipulador.read())
#manipulador.seek(0)

#print(manipulador.readline())
#print(manipulador.readline())
#print(manipulador.readline())
#print(manipulador.readline())
#print(manipulador.readline())
#print(manipulador.readline())

#manipulador.seek(0)

#print(manipulador.readline())

#manipulador.close()
